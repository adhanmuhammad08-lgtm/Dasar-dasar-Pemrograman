import math

# --- LUAS BANGUN DATAR ---
def luas_lingkaran(jari_jari):
    hasil = math.pi * (jari_jari ** 2)
    print(f"Luas Lingkaran (r={jari_jari}) = {hasil:.2f}")

def luas_segitiga(alas, tinggi):
    hasil = 0.5 * alas * tinggi
    print(f"Luas Segitiga (a={alas}, t={tinggi}) = {hasil}")

def luas_persegi(sisi):
    hasil = sisi * sisi
    print(f"Luas Persegi (sisi={sisi}) = {hasil}")

# --- KELILING BANGUN DATAR ---
def keliling_lingkaran(jari_jari):
    hasil = 2 * math.pi * jari_jari
    print(f"Keliling Lingkaran (r={jari_jari}) = {hasil:.2f}")

def keliling_segitiga(sisi1, sisi2, sisi3):
    hasil = sisi1 + sisi2 + sisi3
    print(f"Keliling Segitiga ({sisi1}, {sisi2}, {sisi3}) = {hasil}")

def keliling_persegi(sisi):
    hasil = 4 * sisi
    print(f"Keliling Persegi (sisi={sisi}) = {hasil}")