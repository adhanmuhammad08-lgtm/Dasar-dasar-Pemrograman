import math

def volume_kubus(sisi):
    hasil = sisi ** 3
    print(f"Volume Kubus (sisi={sisi}) = {hasil}")

def volume_tabung(jari_jari, tinggi):
    hasil = math.pi * (jari_jari ** 2) * tinggi
    print(f"Volume Tabung (r={jari_jari}, t={tinggi}) = {hasil:.2f}")

def volume_bola(jari_jari):
    hasil = (4/3) * math.pi * (jari_jari ** 3)
    print(f"Volume Bola (r={jari_jari}) = {hasil:.2f}")