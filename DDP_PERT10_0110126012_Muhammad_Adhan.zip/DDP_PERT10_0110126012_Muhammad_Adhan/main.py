import bangunruang as br
import bangundatar as bd

print("=== VOLUME BANGUN RUANG ===")
br.volume_kubus(5)
br.volume_tabung(7, 10)
br.volume_bola(7)

print("\n=== LUAS BANGUN DATAR ===")
bd.luas_lingkaran(7)
bd.luas_segitiga(6, 8)
bd.luas_persegi(4)

print("\n=== KELILING BANGUN DATAR ===")
bd.keliling_lingkaran(7)
bd.keliling_segitiga(3, 4, 5)
bd.keliling_persegi(4)